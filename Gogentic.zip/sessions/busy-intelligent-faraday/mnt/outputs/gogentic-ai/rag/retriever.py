"""
RAG retriever — fetches relevant documents from the vector store.
"""

import os
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from pathlib import Path

_vectorstore = None
INDEX_PATH = Path("rag/faiss_index")


def _get_vectorstore():
    global _vectorstore
    if _vectorstore is None:
        embeddings = OpenAIEmbeddings(api_key=os.getenv("OPENAI_API_KEY"))
        if INDEX_PATH.exists():
            _vectorstore = FAISS.load_local(
                str(INDEX_PATH), embeddings, allow_dangerous_deserialization=True
            )
        else:
            # Empty store — call ingest_documents() to populate
            _vectorstore = FAISS.from_texts(
                ["Placeholder — ingest real documents via ingest_documents()"],
                embeddings,
            )
    return _vectorstore


def retrieve(query: str, k: int = 3) -> list[Document]:
    """
    Retrieve top-k relevant documents for a query.

    Args:
        query: Search query
        k:     Number of documents to retrieve

    Returns:
        List of LangChain Document objects
    """
    vs = _get_vectorstore()
    return vs.similarity_search(query, k=k)


def ingest_documents(texts: list[str], metadatas: list[dict] | None = None):
    """
    Add documents to the vector store and persist the index.

    Args:
        texts:     List of document text strings
        metadatas: Optional metadata dicts per document
    """
    global _vectorstore
    embeddings = OpenAIEmbeddings(api_key=os.getenv("OPENAI_API_KEY"))
    _vectorstore = FAISS.from_texts(texts, embeddings, metadatas=metadatas)
    INDEX_PATH.mkdir(parents=True, exist_ok=True)
    _vectorstore.save_local(str(INDEX_PATH))
    print(f"Ingested {len(texts)} documents and saved index.")
