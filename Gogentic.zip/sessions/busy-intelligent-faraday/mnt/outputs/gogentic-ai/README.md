# 🤖 Gogentic.ai — GenAI Conversational Persona Platform

> A configurable multi-agent conversational AI platform that enables building, deploying, and evaluating custom LLM personas with persistent memory, tool-use, and RAG-backed knowledge.

---

## 🚀 Overview

Gogentic.ai is a production-grade GenAI platform for creating and orchestrating configurable AI personas. Using LangChain and LangGraph, the system supports multi-turn conversational agents with planning, memory management, and dynamic tool-use — evaluated continuously via Judge models and LangSmith observability.

**Key capabilities:**
- Configurable AI personas with few-shot prompting and function calling
- Multi-step agentic workflows with planning, memory, and tool execution
- RAG-backed knowledge retrieval for context-aware responses
- LLM evaluation pipeline using Judge models and LangSmith
- Multi-turn conversation orchestration with persistent state

---

## 🏗️ Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                      Client (JavaScript)                      │
└──────────────────────────┬───────────────────────────────────┘
                           │ WebSocket / REST
┌──────────────────────────▼───────────────────────────────────┐
│                    Orchestration Layer (Python)                │
│                                                               │
│  ┌────────────────────────────────────────────────────────┐  │
│  │               LangGraph Agent Graph                     │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────────────────┐  │  │
│  │  │ Planner  │→ │ Executor │→ │   Memory Manager     │  │  │
│  │  │  Node    │  │  Node    │  │   (short + long term)│  │  │
│  │  └──────────┘  └──────────┘  └──────────────────────┘  │  │
│  └────────────────────────────────────────────────────────┘  │
│                                                               │
│  ┌─────────────────────┐   ┌────────────────────────────┐    │
│  │  Persona Config     │   │   RAG Knowledge Base        │    │
│  │  (few-shot, tools,  │   │   (vector store + retriever)│    │
│  │   system prompt)    │   └────────────────────────────┘    │
│  └─────────────────────┘                                      │
│                                                               │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │           LangSmith Evaluation & Observability           │ │
│  │        (Judge model scoring, trace logging, evals)       │ │
│  └─────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Agent Orchestration | LangGraph, LangChain |
| LLM | OpenAI API (GPT-4, GPT-3.5) |
| Evaluation & Observability | LangSmith, Judge Models |
| RAG | LangChain Retrievers, Vector Store |
| Backend | Python, FastAPI |
| Frontend | JavaScript (Vanilla / React) |
| Memory | In-memory + persistent conversation store |

---

## 📁 Repository Structure

```
gogentic-ai/
│
├── agents/                         # Core agent logic
│   ├── graph.py                    # LangGraph agent graph definition
│   ├── nodes/
│   │   ├── planner.py              # Planning node (task decomposition)
│   │   ├── executor.py             # Tool execution node
│   │   └── memory_manager.py       # Short + long-term memory handling
│   ├── tools/                      # Custom tools available to agents
│   │   ├── search_tool.py
│   │   ├── calculator_tool.py
│   │   └── knowledge_tool.py       # RAG-backed knowledge retrieval
│   └── state.py                    # Shared agent state schema
│
├── personas/                       # Persona configuration files
│   ├── base_persona.py             # Base persona class
│   ├── configs/
│   │   ├── customer_support.yaml   # Example persona config
│   │   ├── sales_assistant.yaml
│   │   └── technical_advisor.yaml
│   └── loader.py                   # Load and validate persona configs
│
├── rag/                            # RAG pipeline
│   ├── vectorstore.py              # Vector store setup and management
│   ├── retriever.py                # Retriever configuration
│   ├── embeddings.py               # Embedding generation
│   └── ingestion.py                # Document ingestion pipeline
│
├── evaluation/                     # LLM evaluation system
│   ├── judge_model.py              # Judge model evaluator
│   ├── metrics.py                  # Accuracy, latency, cost metrics
│   ├── run_evals.py                # Evaluation runner script
│   └── eval_datasets/             # Test cases for evaluation
│       ├── qa_pairs.json
│       └── conversation_flows.json
│
├── api/                            # FastAPI backend
│   ├── main.py                     # App entry point
│   ├── routes/
│   │   ├── chat.py                 # Chat endpoint (/chat)
│   │   ├── personas.py             # Persona management endpoints
│   │   └── evals.py                # Trigger evaluation runs
│   └── middleware/
│       └── auth.py
│
├── frontend/                       # JavaScript client
│   ├── index.html
│   ├── chat.js                     # Chat UI logic
│   └── styles.css
│
├── notebooks/                      # Exploration & demos
│   ├── 01_persona_demo.ipynb       # Persona configuration walkthrough
│   ├── 02_langgraph_flow.ipynb     # LangGraph agent flow visualization
│   ├── 03_rag_demo.ipynb           # RAG pipeline demo
│   └── 04_evaluation_results.ipynb # Evaluation metrics and results
│
├── tests/
│   ├── test_agents.py
│   ├── test_rag.py
│   └── test_personas.py
│
├── docker-compose.yml
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

---

## ⚙️ Setup & Installation

### Prerequisites
- Python 3.10+
- OpenAI API key
- LangSmith API key (free tier available at smith.langchain.com)

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/gogentic-ai.git
cd gogentic-ai
```

### 2. Install dependencies
```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure environment variables
```bash
cp .env.example .env
# Fill in your API keys
```

### 4. Run the API server
```bash
uvicorn api.main:app --reload
```

---

## 🔑 Environment Variables

```env
# LLM
OPENAI_API_KEY=your_openai_key_here

# LangSmith (Observability)
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=your_langsmith_key_here
LANGCHAIN_PROJECT=gogentic-ai

# App
SECRET_KEY=your_secret_key
```

> ⚠️ Never commit your `.env` file. It is listed in `.gitignore`.

---

## 🧠 Key Technical Highlights

### LangGraph Multi-Step Agent
The core agent is implemented as a LangGraph `StateGraph` with distinct planner, executor, and memory nodes enabling complex multi-turn reasoning.

```python
from langgraph.graph import StateGraph, END
from agents.nodes import planner, executor, memory_manager
from agents.state import AgentState

graph = StateGraph(AgentState)
graph.add_node("planner", planner.run)
graph.add_node("executor", executor.run)
graph.add_node("memory", memory_manager.run)

graph.set_entry_point("planner")
graph.add_edge("planner", "executor")
graph.add_edge("executor", "memory")
graph.add_conditional_edges("memory", should_continue, {"continue": "planner", "end": END})

agent = graph.compile()
```

### Configurable Personas via YAML
Personas are defined in YAML config files and loaded at runtime, enabling no-code persona creation.

```yaml
# personas/configs/customer_support.yaml
name: "SupportBot"
role: "Customer Support Specialist"
few_shot_examples:
  - input: "How do I reset my password?"
    output: "I can help with that! Please go to Settings > Account > Reset Password."
tools: ["search_tool", "knowledge_tool"]
memory_type: "buffer_window"
temperature: 0.3
```

### LLM Evaluation with Judge Models
Every agent response is scored by a Judge LLM for relevance, accuracy, and tone — logged to LangSmith for continuous monitoring.

```python
from langsmith import Client
from evaluation.judge_model import JudgeEvaluator

evaluator = JudgeEvaluator(criteria=["correctness", "helpfulness", "conciseness"])
results = evaluator.evaluate_run(run_id="abc123")
# Logs scores + traces automatically to LangSmith dashboard
```

---

## 📊 Evaluation Metrics

| Metric | Description |
|--------|-------------|
| Response Accuracy | Judge model score (0–1) on correctness |
| Latency | End-to-end response time (ms) |
| Token Cost | Estimated cost per conversation turn |
| Memory Hit Rate | % of turns that leveraged stored context |
| Tool Usage Rate | % of turns that triggered tool calls |

---

## 🧪 Running Tests

```bash
pytest tests/ -v
```

## 🧪 Running Evaluations

```bash
python evaluation/run_evals.py --dataset eval_datasets/qa_pairs.json --persona customer_support
```

---

## 📄 .gitignore (recommended)

```
# Environment
.env
*.env

# Python
__pycache__/
*.pyc
.venv/
venv/

# LangSmith local cache
.langchain/

# IDE
.vscode/
.idea/

# Secrets & keys
*.pem
*.key
secrets/
credentials.json
```

---

## 👩‍💻 Author

**Janani Reddy Govuri**
[LinkedIn](https://linkedin.com/in/janani-reddy-160103277) | [Email](mailto:jananireddy81@gmail.com)
