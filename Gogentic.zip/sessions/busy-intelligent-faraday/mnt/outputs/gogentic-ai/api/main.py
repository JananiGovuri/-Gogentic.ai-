"""FastAPI application entry point."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.routes import chat, personas

app = FastAPI(
    title="Gogentic.ai API",
    description="GenAI Conversational Persona Platform",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(chat.router)
app.include_router(personas.router)


@app.get("/health")
def health():
    return {"status": "ok"}
