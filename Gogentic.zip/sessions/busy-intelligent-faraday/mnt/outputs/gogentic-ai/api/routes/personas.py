"""Persona management endpoints."""

from fastapi import APIRouter, HTTPException
from personas.loader import load_persona, list_personas

router = APIRouter(prefix="/api/personas", tags=["personas"])


@router.get("/")
def get_all_personas():
    """GET /api/personas/ — List all available persona names."""
    return {"personas": list_personas()}


@router.get("/{name}")
def get_persona(name: str):
    """GET /api/personas/<name> — Return persona config."""
    try:
        return load_persona(name)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"Persona '{name}' not found")
