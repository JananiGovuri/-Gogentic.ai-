"""Chat endpoint — accepts a user message and returns an agent response."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from langchain_core.messages import HumanMessage

from agents.graph import get_agent

router = APIRouter(prefix="/api/chat", tags=["chat"])


class ChatRequest(BaseModel):
    message: str
    persona: str = "customer_support"
    conversation_id: str | None = None


class ChatResponse(BaseModel):
    reply: str
    persona: str
    conversation_id: str | None


@router.post("/", response_model=ChatResponse)
def chat(request: ChatRequest):
    """
    POST /api/chat/
    Send a message to the agent and receive a response.
    """
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    agent = get_agent()

    initial_state = {
        "messages":        [HumanMessage(content=request.message)],
        "current_task":    request.message,
        "plan_steps":      [],
        "tool_results":    [],
        "iteration_count": 0,
        "persona_name":    request.persona,
        "should_continue": True,
    }

    try:
        final_state = agent.invoke(initial_state)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Agent error: {str(e)}")

    ai_messages = [
        m for m in final_state["messages"]
        if hasattr(m, "type") and m.type == "ai"
    ]
    reply = ai_messages[-1].content if ai_messages else "I'm sorry, I couldn't generate a response."

    return ChatResponse(
        reply=reply,
        persona=request.persona,
        conversation_id=request.conversation_id,
    )
