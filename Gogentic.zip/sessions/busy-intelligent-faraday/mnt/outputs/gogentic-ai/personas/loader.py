"""Load and validate persona configs from YAML files."""

import os
import yaml
from pathlib import Path

CONFIGS_DIR = Path(__file__).parent / "configs"


def load_persona(name: str) -> dict:
    """
    Load a persona configuration by name.

    Args:
        name: Persona config filename without extension (e.g. 'customer_support')

    Returns:
        Persona config dict

    Raises:
        FileNotFoundError: If config file does not exist
    """
    config_path = CONFIGS_DIR / f"{name}.yaml"
    if not config_path.exists():
        raise FileNotFoundError(f"Persona config not found: {config_path}")

    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    _validate(config, name)
    return config


def _validate(config: dict, name: str):
    required = ["name", "role"]
    for field in required:
        if field not in config:
            raise ValueError(f"Persona '{name}' is missing required field: '{field}'")


def list_personas() -> list[str]:
    """Return names of all available persona configs."""
    return [p.stem for p in CONFIGS_DIR.glob("*.yaml")]
