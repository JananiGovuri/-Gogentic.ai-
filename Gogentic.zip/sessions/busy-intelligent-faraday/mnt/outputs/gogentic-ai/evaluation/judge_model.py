"""
LLM-as-Judge evaluation system.
Scores agent responses on correctness, helpfulness, and conciseness.
Integrates with LangSmith for trace logging and eval dashboards.
"""

import os
from dataclasses import dataclass
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langsmith import Client as LangSmithClient
from langsmith.evaluation import evaluate, LangChainStringEvaluator


@dataclass
class EvalResult:
    run_id: str
    score: float           # 0.0 – 1.0
    correctness: float
    helpfulness: float
    conciseness: float
    feedback: str


JUDGE_SYSTEM_PROMPT = """You are an expert evaluator for AI assistant responses.
Score the following response on three dimensions (each 0.0 to 1.0):
- correctness:  Is the response factually accurate?
- helpfulness:  Does it fully address the user's question?
- conciseness:  Is it appropriately concise without missing key info?

Return ONLY a JSON object like:
{"correctness": 0.9, "helpfulness": 0.85, "conciseness": 0.8, "feedback": "..."}
"""


class JudgeEvaluator:
    def __init__(self, model: str = "gpt-4o-mini"):
        self.llm = ChatOpenAI(
            model=model,
            temperature=0,
            api_key=os.getenv("OPENAI_API_KEY"),
        )
        self.langsmith = LangSmithClient(api_key=os.getenv("LANGCHAIN_API_KEY"))

    def score_response(self, user_input: str, agent_response: str, reference: str = "") -> EvalResult:
        """
        Score a single agent response using the Judge LLM.

        Args:
            user_input:     Original user message
            agent_response: Agent's reply
            reference:      Optional ground-truth answer for comparison

        Returns:
            EvalResult with per-dimension scores
        """
        user_prompt = (
            f"User message: {user_input}\n\n"
            f"Agent response: {agent_response}\n\n"
            + (f"Reference answer: {reference}\n\n" if reference else "")
            + "Score this response."
        )

        response = self.llm.invoke([
            SystemMessage(content=JUDGE_SYSTEM_PROMPT),
            HumanMessage(content=user_prompt),
        ])

        import json, re
        content = response.content
        match = re.search(r'\{.*\}', content, re.DOTALL)
        scores = json.loads(match.group()) if match else {}

        avg_score = round(
            (scores.get("correctness", 0) + scores.get("helpfulness", 0) + scores.get("conciseness", 0)) / 3,
            4,
        )

        return EvalResult(
            run_id="",
            score=avg_score,
            correctness=scores.get("correctness", 0),
            helpfulness=scores.get("helpfulness", 0),
            conciseness=scores.get("conciseness", 0),
            feedback=scores.get("feedback", ""),
        )

    def evaluate_dataset(self, dataset_name: str, agent_fn) -> list[EvalResult]:
        """
        Run evaluation over a LangSmith dataset.

        Args:
            dataset_name: Name of the dataset in LangSmith
            agent_fn:     Callable(input: str) -> str

        Returns:
            List of EvalResult objects
        """
        dataset = self.langsmith.read_dataset(dataset_name=dataset_name)
        examples = list(self.langsmith.list_examples(dataset_id=dataset.id))

        results = []
        for ex in examples:
            user_input = ex.inputs.get("input", "")
            reference  = ex.outputs.get("output", "") if ex.outputs else ""
            response   = agent_fn(user_input)
            result     = self.score_response(user_input, response, reference)
            result.run_id = str(ex.id)
            results.append(result)

        self._log_to_langsmith(results, dataset_name)
        return results

    def _log_to_langsmith(self, results: list[EvalResult], dataset_name: str):
        """Log aggregate metrics to LangSmith."""
        avg = sum(r.score for r in results) / max(len(results), 1)
        print(f"[LangSmith] Dataset: {dataset_name} | Avg score: {avg:.3f} | N={len(results)}")
