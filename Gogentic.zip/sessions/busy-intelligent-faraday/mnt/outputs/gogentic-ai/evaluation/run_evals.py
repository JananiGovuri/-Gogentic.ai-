"""
Evaluation runner — scores agent responses against a test dataset.
Usage:
    python evaluation/run_evals.py --persona customer_support --dataset eval_datasets/qa_pairs.json
"""

import argparse
import json
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

from evaluation.judge_model import JudgeEvaluator
from agents.graph import get_agent
from langchain_core.messages import HumanMessage


def run_agent(user_input: str, persona: str) -> str:
    """Run the agent graph for a single user message."""
    agent = get_agent()
    state = {
        "messages":       [HumanMessage(content=user_input)],
        "current_task":   user_input,
        "plan_steps":     [],
        "tool_results":   [],
        "iteration_count": 0,
        "persona_name":   persona,
        "should_continue": True,
    }
    final_state = agent.invoke(state)
    ai_messages = [m for m in final_state["messages"] if hasattr(m, "type") and m.type == "ai"]
    return ai_messages[-1].content if ai_messages else ""


def main():
    parser = argparse.ArgumentParser(description="Run LLM evaluations")
    parser.add_argument("--persona",  default="customer_support", help="Persona config name")
    parser.add_argument("--dataset",  default="evaluation/eval_datasets/qa_pairs.json", help="Path to eval dataset JSON")
    parser.add_argument("--output",   default="evaluation/eval_results.json", help="Where to save results")
    args = parser.parse_args()

    # Load dataset
    dataset_path = Path(args.dataset)
    if not dataset_path.exists():
        print(f"Dataset not found: {dataset_path}")
        return

    with open(dataset_path) as f:
        examples = json.load(f)

    evaluator = JudgeEvaluator()
    results = []

    for i, ex in enumerate(examples):
        user_input = ex.get("input", "")
        reference  = ex.get("expected_output", "")
        print(f"[{i+1}/{len(examples)}] Evaluating: {user_input[:60]}...")

        response = run_agent(user_input, persona=args.persona)
        result   = evaluator.score_response(user_input, response, reference)
        results.append({
            "input":        user_input,
            "response":     response,
            "reference":    reference,
            "score":        result.score,
            "correctness":  result.correctness,
            "helpfulness":  result.helpfulness,
            "conciseness":  result.conciseness,
            "feedback":     result.feedback,
        })

    # Summary
    avg_score = sum(r["score"] for r in results) / max(len(results), 1)
    print(f"\n{'='*50}")
    print(f"Evaluation complete | N={len(results)} | Avg score: {avg_score:.3f}")
    print(f"{'='*50}")

    # Save
    with open(args.output, "w") as f:
        json.dump(results, f, indent=2)
    print(f"Results saved to {args.output}")


if __name__ == "__main__":
    main()
