"""
Executor node — runs tool calls and generates the final response.
Supports function-calling with registered tools and RAG retrieval.
"""

import os
import json
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, AIMessage
from langchain_core.tools import tool

from agents.state import AgentState
from agents.tools.search_tool import web_search
from agents.tools.knowledge_tool import rag_lookup
from personas.loader import load_persona


def run(state: AgentState) -> AgentState:
    """
    Executor node: runs the plan using available tools and produces a reply.
    """
    persona = load_persona(state["persona_name"])
    allowed_tools = persona.get("tools", [])

    # Build tool list based on persona config
    available_tools = []
    if "search_tool" in allowed_tools:
        available_tools.append(web_search)
    if "knowledge_tool" in allowed_tools:
        available_tools.append(rag_lookup)

    llm = ChatOpenAI(
        model="gpt-4o",
        temperature=float(persona.get("temperature", 0.3)),
        api_key=os.getenv("OPENAI_API_KEY"),
    )

    llm_with_tools = llm.bind_tools(available_tools) if available_tools else llm

    system_prompt = (
        f"You are {persona['name']}, a {persona['role']}. "
        "Use the available tools when needed. Be concise and helpful. "
        f"Plan to follow: {'; '.join(state['plan_steps'])}"
    )

    messages = [SystemMessage(content=system_prompt)] + state["messages"]
    response = llm_with_tools.invoke(messages)

    # Handle tool calls if present
    tool_results = list(state.get("tool_results", []))
    if hasattr(response, "tool_calls") and response.tool_calls:
        for tc in response.tool_calls:
            tool_name = tc["name"]
            tool_args = tc["args"]
            if tool_name == "web_search":
                result = web_search.invoke(tool_args)
            elif tool_name == "rag_lookup":
                result = rag_lookup.invoke(tool_args)
            else:
                result = {"error": f"Unknown tool: {tool_name}"}
            tool_results.append({"tool": tool_name, "args": tool_args, "result": result})

    return {
        **state,
        "messages": state["messages"] + [AIMessage(content=response.content)],
        "tool_results": tool_results,
    }
