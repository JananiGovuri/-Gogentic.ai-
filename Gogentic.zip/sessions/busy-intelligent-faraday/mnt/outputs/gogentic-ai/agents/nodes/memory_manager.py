"""
Memory manager node — maintains short-term and long-term conversation context.
"""

from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from agents.state import AgentState

# Short-term memory: keep the last N message pairs
SHORT_TERM_WINDOW = 10


def run(state: AgentState) -> AgentState:
    """
    Memory node: prune old messages to stay within context window.
    Preserves the last SHORT_TERM_WINDOW messages (human + AI pairs).
    """
    messages = state["messages"]

    # Keep system-level context plus recent turns
    pruned = _prune_messages(messages, window=SHORT_TERM_WINDOW)

    # Decide whether the agent should continue looping
    last_ai = next(
        (m for m in reversed(pruned) if isinstance(m, AIMessage)), None
    )
    # Simple heuristic: if the last AI message contains a question, keep going
    should_continue = (
        last_ai is not None
        and "?" in last_ai.content
        and state["iteration_count"] < 5
    )

    return {
        **state,
        "messages": pruned,
        "should_continue": should_continue,
    }


def _prune_messages(messages: list[BaseMessage], window: int) -> list[BaseMessage]:
    """Keep only the most recent `window` messages."""
    if len(messages) <= window:
        return messages
    return messages[-window:]
