"""
Planner node — decomposes user intent into actionable steps.
Uses few-shot prompting and the persona's system configuration.
"""

import os
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate

from agents.state import AgentState
from personas.loader import load_persona


MAX_ITERATIONS = 5


def run(state: AgentState) -> AgentState:
    """
    Planner node: analyse the latest user message and produce a plan.
    Returns updated state with plan_steps populated.
    """
    # Guard against infinite planning loops
    if state["iteration_count"] >= MAX_ITERATIONS:
        state["should_continue"] = False
        return state

    persona = load_persona(state["persona_name"])
    llm = ChatOpenAI(
        model="gpt-4o",
        temperature=0.1,
        api_key=os.getenv("OPENAI_API_KEY"),
    )

    # Build few-shot system prompt from persona config
    few_shot_block = "\n\n".join(
        f"User: {ex['input']}\nAssistant: {ex['output']}"
        for ex in persona.get("few_shot_examples", [])
    )

    system_prompt = (
        f"You are {persona['name']}, a {persona['role']}.\n\n"
        f"Examples of how you respond:\n{few_shot_block}\n\n"
        "Given the latest user message, produce a numbered list of steps you will take "
        "to respond accurately and helpfully. Be concise — 1 to 4 steps max."
    )

    # Latest user message
    last_human = next(
        (m.content for m in reversed(state["messages"]) if isinstance(m, HumanMessage)),
        "",
    )

    response = llm.invoke([
        SystemMessage(content=system_prompt),
        HumanMessage(content=f"Plan how to respond to: {last_human}"),
    ])

    # Parse numbered steps from LLM output
    raw_steps = response.content.strip().split("\n")
    steps = [s.lstrip("0123456789. ").strip() for s in raw_steps if s.strip()]

    return {
        **state,
        "plan_steps": steps,
        "current_task": last_human,
        "iteration_count": state["iteration_count"] + 1,
        "should_continue": True,
    }
