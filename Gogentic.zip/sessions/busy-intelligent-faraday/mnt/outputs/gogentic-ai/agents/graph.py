"""
LangGraph agent graph definition.
Wires together planner → executor → memory nodes with conditional looping.
"""

from langgraph.graph import StateGraph, END
from agents.state import AgentState
from agents.nodes import planner, executor, memory_manager


def should_continue(state: AgentState) -> str:
    """Routing function: continue planning or end the conversation turn."""
    if state.get("should_continue") and state.get("iteration_count", 0) < 5:
        return "continue"
    return "end"


def build_graph() -> StateGraph:
    """Build and compile the agent graph."""
    graph = StateGraph(AgentState)

    # Register nodes
    graph.add_node("planner",  planner.run)
    graph.add_node("executor", executor.run)
    graph.add_node("memory",   memory_manager.run)

    # Entry point
    graph.set_entry_point("planner")

    # Edges
    graph.add_edge("planner",  "executor")
    graph.add_edge("executor", "memory")

    # Conditional: loop back to planner or end
    graph.add_conditional_edges(
        "memory",
        should_continue,
        {"continue": "planner", "end": END},
    )

    return graph.compile()


# Singleton compiled graph
_graph = None


def get_agent():
    """Get or build the compiled agent graph (singleton)."""
    global _graph
    if _graph is None:
        _graph = build_graph()
    return _graph
