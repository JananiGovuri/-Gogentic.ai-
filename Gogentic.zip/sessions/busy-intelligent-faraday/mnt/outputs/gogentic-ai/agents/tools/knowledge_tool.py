"""RAG-backed knowledge retrieval tool for agents."""

from langchain_core.tools import tool
from rag.retriever import retrieve


@tool
def rag_lookup(query: str) -> str:
    """
    Look up information from the persona's knowledge base using RAG.

    Use this when the user asks a question that requires specific knowledge
    stored in the vector database (product docs, FAQs, policies, etc.).

    Args:
        query: The question or topic to look up

    Returns:
        Relevant context passages as a string
    """
    docs = retrieve(query=query, k=3)
    if not docs:
        return "No relevant information found in the knowledge base."
    return "\n\n---\n\n".join(doc.page_content for doc in docs)
