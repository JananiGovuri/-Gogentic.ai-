"""Web search tool for agents (uses DuckDuckGo — no API key required)."""

from langchain_core.tools import tool
from langchain_community.tools import DuckDuckGoSearchRun

_search = DuckDuckGoSearchRun()


@tool
def web_search(query: str) -> str:
    """
    Search the web for current information.

    Use this when you need up-to-date facts, news, or information not in
    the knowledge base.

    Args:
        query: Search query string

    Returns:
        Search result snippets as a string
    """
    try:
        return _search.run(query)
    except Exception as e:
        return f"Search failed: {str(e)}"
