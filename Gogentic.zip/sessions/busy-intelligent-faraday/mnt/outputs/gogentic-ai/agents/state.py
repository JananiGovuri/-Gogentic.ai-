"""Shared state schema for the LangGraph agent."""

from typing import Annotated, TypedDict
from langchain_core.messages import BaseMessage
import operator


class AgentState(TypedDict):
    """State passed between nodes in the LangGraph graph."""

    # Conversation history — messages are appended, never overwritten
    messages: Annotated[list[BaseMessage], operator.add]

    # Current task or goal the planner is working toward
    current_task: str

    # Intermediate plan steps produced by the planner node
    plan_steps: list[str]

    # Tool outputs collected during execution
    tool_results: list[dict]

    # Number of planner iterations (guards against infinite loops)
    iteration_count: int

    # Persona config name currently active
    persona_name: str

    # Whether the conversation should continue or end
    should_continue: bool
